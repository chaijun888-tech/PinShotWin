﻿PinShotWin

Version: 0.2.0

Quick start:
1. Double-click PinShotWin.exe. The app runs in the system tray.
2. Press F1 to capture. Press Esc to cancel.

Install for current Windows user:
1. Open PowerShell in this folder.
2. Run: powershell -ExecutionPolicy Bypass -File .\install.ps1
3. The installer creates Desktop and Start Menu shortcuts and enables startup.

Uninstall:
1. Run "Uninstall PinShotWin" from Start Menu, or run:
   powershell -ExecutionPolicy Bypass -File .\uninstall.ps1

Usage:
1. Drag to select, then adjust the blue frame or handles.
2. Toolbar actions: copy, save, pin, cancel.
3. Preview shortcuts: Enter/Ctrl+C copy, Ctrl+S save, Ctrl+P pin.
4. Preview selection: arrow keys nudge, Ctrl+arrow resizes, Shift uses 10px steps.
5. Pinned images support right-click: copy, save, lock position, opacity, close.
6. Tray menu supports settings, recent screenshots, about, and exit.
7. Recent screenshots are in-memory only, keep latest 10, and clear on exit.

If Windows shows an unknown publisher warning, choose "More info" and continue.
